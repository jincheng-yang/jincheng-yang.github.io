function [ output_args ] = compstr ( corr, input_args )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
a = 0;
b = 0;

for i = 1 : 4
    if corr(i) == input_args(i)
        a = a + 1;
    end
    for j = 1 : 4
        if corr(i) == input_args(j)
            b = b + 1;
            break;
        end
    end
end

output_args = [num2str(a), 'A', num2str(b), 'B'];

end