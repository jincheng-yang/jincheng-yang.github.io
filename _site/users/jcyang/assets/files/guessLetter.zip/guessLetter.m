s = input('Hey! Let''s play Guessing Letters! \nInput your favorate word (A-Z), or let the computer generate one (press <Enter>).\n', 's');

word = s;
if isempty(word)
    word = 'AAAA';
    for i = 1 : 4
        word(i) = word(i) + floor(rand * 26);
    end
end

tryTime = 0;
result = '0A0B';
while strcmp(result, '4A4B') == false
    tryTime = tryTime + 1;
    input_args = input(['No. ', num2str(tryTime), ': '], 's');
    result = compstr(word, input_args);
    disp([input_args, ': ', result]);
end

disp(['Conguratulations! The correct answer is ', word]);