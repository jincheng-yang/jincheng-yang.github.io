lLetter = 'Z';
ldim = lLetter - 'A' + 1;

%----guessLetterAI-----Init
len = ldim ^ 4;
wordPool = zeros(len, 4);
active = ones(len, 1);
thisWord = 'AAAA';
for i = 1 : len
    wordPool(i, :) = thisWord;
    thisWord(4) = thisWord(4) + 1;
    if thisWord(4) == lLetter + 1
        thisWord(4) = 'A';
        thisWord(3) = thisWord(3) + 1;
        if thisWord(3) == lLetter + 1
            thisWord(3) = 'A';
            thisWord(2) = thisWord(2) + 1;
            if thisWord(2) == lLetter + 1
                thisWord(2) = 'A';
                thisWord(1) = thisWord(1) + 1;
            end
        end
    end
end

%----guessLetterAI----Loop
guess = 'ABCD';
results = input([guess, '? '], 's');
if length(results) == 4
    resNum = results([1, 3]) - '0';
else
    resNum = results([1, 2]) - '0';
end
testDepth = 4;

while ~(strcmp(results, '4A4B') || strcmp(results, '44'))
    for i = 1 : len
        if active(i)
            active(i) = (sumsqr(comp(wordPool(i, :), guess) - resNum) == 0);
        end
    end

    minEntropy = 1;
    bestSelection = 1;
    
    biggestLetter = max(guess) - 'A' + 1;
    if testDepth < min(biggestLetter + 4, ldim)
        testDepth = min(biggestLetter + 4, ldim);
        testPool = [];
        testPoolJ = [];
        for i3 = 0 : testDepth - 1
            for i2 = 0 : testDepth - 1
                for i1 = 0 : testDepth - 1
                    for i0 = 0 : testDepth - 1
                        thisNumber = i0 * 1 + i1 * ldim + i2 * ldim ^ 2 + i3 * ldim ^ 3;
                        if active(thisNumber + 1)
                            testPool = [testPool, thisNumber];
                        end
                    end
                end
            end
        end
        testPool = testPool + 1;
        
        for i3 = 0 : min(testDepth + 3, ldim - 1)
            for i2 = 0 : min(testDepth + 3, ldim - 1)
                for i1 = 0 : min(testDepth + 3, ldim - 1)
                    for i0 = 0 : min(testDepth + 3, ldim - 1)
                        thisNumber = i0 * 1 + i1 * ldim + i2 * ldim ^ 2 + i3 * ldim ^ 3;
                        if active(thisNumber + 1)
                            testPoolJ = [testPoolJ, thisNumber];
                        end
                    end
                end
            end
        end
        testPoolJ = testPoolJ + 1;
    end

%     countActiveI = 0;
    for i = testPool
        if active(i)
%             countActiveI = countActiveI + 1;
%             if countActiveI > 2
%                 break;
%             end
            psbOtcm = zeros(5);
            ctPsbOtcm = 0;
            for j = testPoolJ %1 : len
                if active(j)
                    compij = comp(wordPool(j, :), wordPool(i, :));
                    psbOtcm(compij(1) + 1, compij(2) + 1) = psbOtcm(compij(1) + 1, compij(2) + 1) + 1;
                    ctPsbOtcm = ctPsbOtcm + 1;
                end
            end
            psbOtcm = psbOtcm / ctPsbOtcm;

            entropy = 0;
            for i1 = 1 : 5
                for j1 = 1 : 5
                    psblty = psbOtcm(i1, j1);
                    if psblty > 0
                        entropy = entropy + psblty * log(psblty);
                    end
                end
            end

            if entropy < minEntropy
                minEntropy = entropy;
                bestSelection = i;
            end
        end
    end

    guess = char(wordPool(bestSelection, :));
    results = input([guess, '? '], 's');
    if length(results) == 4
        resNum = results([1, 3]) - '0';
    else
        resNum = results([1, 2]) - '0';
    end
end

