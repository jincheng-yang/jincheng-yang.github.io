%----guessLetterAI-----Init
len = 10 ^ 4;
wordPool = zeros(len, 4);
active = ones(len, 1);
thisWord = 'AAAA';
for i = 1 : len
    wordPool(i, :) = thisWord;
    thisWord(4) = thisWord(4) + 1;
    if thisWord(4) == 'K'
        thisWord(4) = 'A';
        thisWord(3) = thisWord(3) + 1;
        if thisWord(3) == 'K'
            thisWord(3) = 'A';
            thisWord(2) = thisWord(2) + 1;
            if thisWord(2) == 'K'
                thisWord(2) = 'A';
                thisWord(1) = thisWord(1) + 1;
            end
        end
    end
end

%----guessLetterAI----Loop
guess = 'ABCD';
results = input([guess, '? '], 's');
resNum = results([1, 3]) - '0';
testDepth = 4;

while ~strcmp(results, '4A4B')
    for i = 1 : len
        if active(i)
            active(i) = (sumsqr(comp(wordPool(i, :), guess) - resNum) == 0);
        end
    end

    minEntropy = 0;
    bestSelection = 1;
    
    biggestLetter = max(guess) - 'A' + 1;
    if testDepth < min(biggestLetter + 4, 10)
        testDepth = min(biggestLetter + 4, 10);
        testPool = [];
        for i3 = 0 : testDepth - 1
            for i2 = 0 : testDepth - 1
                for i1 = 0 : testDepth - 1
                    for i0 = 0 : testDepth - 1
                        testPool = [testPool, i0 * 1 + i1 * 10 + i2 * 100 + i3 * 1000];
                    end
                end
            end
        end
        testPool = testPool + 1;
    end

    for i = testPool
        if active(i)
            psbOtcm = zeros(5);
            ctPsbOtcm = 0;
            for j = 1 : len
                if active(j)
                    compij = comp(wordPool(j, :), wordPool(i, :));
                    psbOtcm(compij(1) + 1, compij(2) + 1) = psbOtcm(compij(1) + 1, compij(2) + 1) + 1;
                    ctPsbOtcm = ctPsbOtcm + 1;
                end
            end
            psbOtcm = psbOtcm / ctPsbOtcm;

            entropy = 0;
            for i1 = 1 : 5
                for j1 = 1 : 5
                    psblty = psbOtcm(i1, j1);
                    if psblty > 0
                        entropy = entropy + psblty * log(psblty);
                    end
                end
            end

            if entropy < minEntropy
                minEntropy = entropy;
                bestSelection = i;
            end
        end
    end

    guess = char(wordPool(bestSelection, :));
    results = input([guess, '? '], 's');
    resNum = results([1, 3]) - '0';
end

